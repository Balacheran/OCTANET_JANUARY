import java.io.*;
class Celsius
{
public static void main(String[] args)
{
double F=64;
double C = ((F-32)/9)*5 ;
System.out.println(C);
}
}